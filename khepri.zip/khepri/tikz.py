import sys
from os import path
sys.path.append(path.dirname(sys.path[0]))
from khepri.shape import *
from khepri.util import *
from khepri.coords import *
import numbers
import math
from functools import reduce


import io

tikz_port = io.StringIO()

def tikz(obj):
    tikz_port.write(str(obj))

def tikzln(obj):
    tikz_port.write(str(obj))
    tikz_port.write('\n')

def get_accumulated_tikz():
    global tikz_port
    str = tikz_port.getvalue()
    tikz_port.close()
    tikz_port = io.StringIO()    
    return str

"""
(define (save-tikz [pathname : Path-String])
  (with-output-to-file pathname
    (lambda ()
      (write-bytes (get-output-bytes tikz-port #t)))))
"""

def display_tikz():
    print(get_accumulated_tikz())

def tikz_output():
    return get_accumulated_tikz()


def radians2degrees(r):
    return r*180/math.pi


def tikz_end():
    tikzln(';')

def tikz_e(arg):
    tikz(arg)
    tikz_end()

def tikz_draw(is_fill=False):
    tikz('\\fill ' if is_fill else '\\draw ')

def tikz_number(x):
    if isinstance(x, int):
        tikz(x)
    else:
        if abs(x) < 0.0001:
            tikz(0)
        else:
            tikz(round(x*10000.0)/10000.0)

def tikz_cm(x):
    tikz_number(x)
    tikz('cm')
    
def tikz_coord(c):
    tikz('(')
    tikz_number(c.x)
    tikz(',')
    tikz_number(c.y)
    if not c.z == 0:
        tikz(',')
        tikz_number(c.z)
    tikz(')')

def tikz_pgfpoint(c):
    if not 0 == c.z:
        raise RuntimeError("Can't handle 3D coords")
    tikz('\\pgfpoint{')
    tikz_cm(c.x)
    tikz('}{')
    tikz_cm(c.y)
    tikz('}')

def tikz_circle(c, r, is_fill=False):
    tikz_draw(is_fill)
    tikz_coord(c)
    tikz('circle(')
    tikz_cm(r)
    tikz_e(')')

def tikz_point(c):
    circle(c, 0.01)

def tikz_ellipse(c, r0, r1, fi, is_fill=False):
    tikz_draw(is_fill)
    tikz('[shift={')
    tikz_coord(c)
    tikz('}]')
    tikz('[rotate=')
    tikz_number(radians2degrees(fi))
    tikz(']')
    tikz('(0,0)')
    tikz('ellipse(')
    tikz_cm(r0)
    tikz(' and ')
    tikz_cm(r1)
    tikz_e(')')

def tikz_arc(c, r, ai, af, is_fill=False):
    tikz_draw(is_fill)
    if is_fill:
        tikz_coord(c)
        tikz('--')
    tikz_coord(c + vpol(r, ai))
    tikz('arc(')
    tikz_number(radians2degrees(ai))
    tikz(':')
    tikz_number(radians2degrees(af + 2*pi if ai > af else af))
    tikz(':')
    tikz_cm(r)
    tikz(')')
    if is_fill:
        tikz_e('--cycle')
    tikz_end()

def tikz_line(pts):
    tikz_draw()
    tikz_coord(pts[0])
    for pt in pts[1:]:
        tikz('--')
        tikz_coord(pt)
    tikz_end()

def tikz_closed_line(pts, is_fill=False):
    tikz_draw(is_fill)
    for pt in pts:
        tikz_coord(pt)
        tikz('--')
    tikz_e('cycle')

def tikz_spline(pts, is_fill=False):
    tikz_draw(is_fill)
    tikz('plot [smooth,tension=1] coordinates {')
    for pt in pts:
        tikz_coord(pt)
    tikz_e('}')

def tikz_closed_spline(pts, is_fill=False):
    tikz_draw(is_fill)
    tikz('plot [smooth cycle,tension=1] coordinates {')
    for pt in pts:
        tikz_coord(pt)
    tikz_e('}')

def tikz_hobby_spline(pts, is_fill=False):
    tikz_draw(is_fill)
    tikz('[hobby]')
    tikz('plot coordinates {')
    for pt in pts:
        tikz_coord(pt)
    tikz_e('}')

def tikz_hobby_closed_spline(pts, is_fill=False):
    tikz_draw(is_fill)
    tikz('[closed hobby]')
    tikz('plot coordinates {')
    for pt in pts:
        tikz_coord(pt)
    tikz_e('}')

def tikz_rectangle(p, w, h, is_fill=False):
    tikz_draw(is_fill)
    tikz_coord(p)
    tikz('rectangle')
    tikz_coord(p + vxy(w, h))
    tikz_end()

def tikz_text(txt, p, h):
    scale_x, scale_y = 3.7*h, 3.7*h
    tikz_draw()
    tikz('[anchor=base west]')
    tikz_coord(p)
    tikz('node[font=\\fontfamily{phv}\\selectfont,outer sep=0pt,inner sep=0pt')
    tikz(',xscale=')
    tikz_number(scale_x)
    tikz(',yscale=')
    tikz_number(scale_y)
    tikz(']{')
    tikz(txt)
    tikz_e('}')

def tikz_transform(f, c):
    tikz('\\begin{scope}')
    tikz('[shift={')
    tikz_coord(c)
    tikz('}]')
    tikz(']')
    f()
    tikz_e('\\end{scope}')

def tikz_set_view(camera, target, lens):
    v, contents = camera - target, get_accumulated_tikz()
    tikz('\\tdplotsetmaincoords{')
    tikz_number(radians2degrees(sph_psi(v)))
    tikz('}{')
    tikz_number(radians2degrees(sph_phi(v)) + 90)
    tikzln('}')
    tikzln('\\begin{tikzpicture}[tdplot_main_coords]')
    tikzln(contents)
    tikzln('\\end{tikzpicture}')



#The TiKZ shape
class shape(base_shape):
    def validate(self, ref):
        return ref

# The actual shapes
@shape_constructor(shape)
def point(position=u0()):
    center = loc_in_world(position)
    return tikz_point(center)

class curve(shape):
    pass

class closed_curve(curve):
    pass

class surface(shape):
    pass

class solid(shape):
    pass

def is_curve(s):
    return isinstance(s, curve)
def is_surface(s):
    return isinstance(s, surface)
def is_solid(s):
    return isinstance(s, solid)

def in_3d(c, f):
    if is_world_cs(c):
        return f(c)
    else:
        return tikz_transform(lambda: f(u0(world_cs)), c)

@shape_constructor(shape)
def point(position=u0()):
    center = loc_in_world(position)
    return tikz_point(center)

@shape_constructor(shape)
def circle(center=u0(), radius=1):
    return in_3d(center, lambda center: tikz_circle(center, radius, False))

@shape_constructor(shape)
def surface_circle(center=u0(), radius=1):
    return in_3d(center, lambda center: tikz_circle(center, radius, True))


def create_arc(c=u0(), r=1, beg_a=0, a=pi, is_fill=False):
    if r == 0:
        return tikz_point(c)
    elif a == 0:
        return tikz_point(c + vpol(r, beg_a))
    elif abs(a) >= 2*pi:
        return tikz_circle(c, r, is_fill)
    else:
        end_a = beg_a + a
        if end_a > beg_a:
            return tikz_arc(c, r, beg_a, end_a, is_fill)
        else:
            return tikz_arc(c, r, end_a, beg_a, is_fill)

@shape_constructor(shape)
def arc(center=u0(), radius=1, start_angle=0, amplitude=pi):
    return in_3d(center,
                 lambda center: create_arc(center, radius, start_angle, amplitude, False))

@shape_constructor(shape)
def surface_arc(center=u0(), radius=1, start_angle=0, amplitude=pi):
    return in_3d(center,
                 lambda center: create_arc(center, radius, start_angle, amplitude, True))

@shape_constructor(shape)
def ellipse(center=u0(), radius_x=1, radius_y=1):
    return in_3d(center,
                 lambda center: tikz_ellipse(center, radius_x, radius_y, 0, False))

@shape_constructor(shape)
def line(*vertices):
    pts = unvarargs(vertices)
    return tikz_line(map(loc_in_world, pts))

@shape_constructor(shape)
def closed_line(*vertices):
    pts = unvarargs(vertices)
    return tikz_closedline(map(loc_in_world, pts))

@shape_constructor(shape)
def polygon(*vertices):
    pts = unvarargs(vertices)
    return tikz_closedline(map(loc_in_world, pts))

@shape_constructor(shape)
def surface_polygon(*vertices):
    pts = unvarargs(vertices)
    return tikz_closedline(map(loc_in_world, pts), True)

@shape_constructor(shape)
def spline(*vertices):
    pts = unvarargs(vertices)
    return tikz_hobby_spline(pts, False)

@shape_constructor(shape)
def closed_spline(*vertices):
    pts = unvarargs(vertices)
    return tikz_hobby_closed_spline(pts, False)

@shape_constructor(shape)
def regular_polygon(edges=3, center=u0(), radius=1, angle=0, is_inscribed=False):
    center = loc_in_world(center)
    if radius == 0 and allow_degenerate_radius():
        return tikz_point(center)
    else:
        pts = regular_polygon_vertices(edges, center, radius, angle, is_inscribed)
        return tikz_line(map(loc_in_world, pts + [pts[0]]))

@shape_constructor(shape)
def rectangle(corner=u0(), dx=1, dy=None):
    dy = dy or dx
    dz = 0
    c = corner
    if isinstance(dx, xyz):
        v = loc_in_cs(dx, c.cs) - c
        dx, dy, dz = v.coords
    assert dz == 0, "The rectangle is not planar"
    return in_3d(c, lambda c: tikz_rectangle(c, dx, dy, False))

@shape_constructor(shape)
def surface_rectangle(corner=u0(), dx=1, dy=None):
    dy = dy or dx
    dz = 0
    c = corner
    if isinstance(dx, xyz):
        v = loc_in_cs(dx, c.cs) - c
        dx, dy, dz = v.coords
    assert dz == 0, "The rectangle is not planar"
    return in_3d(c, lambda c: tikz_rectangle(c, dx, dy, True))

@shape_constructor(shape)
def text(str, p=u0(), h=1):
    return in_3d(p, lambda p: tikz_text(str, p, h))

def text_length(str, h=1):
    return len(str)*h*0.7

@shape_constructor(shape)
def text_centered(str='', p=u0(), h=1):
    return in_3d(p,
                 lambda p: tikz_text(str, p + vxy(-(text_length(str, h)/2), -(h/2)), h))


def transpose_ptss(ptss):
    if ptss[0] == []:
        return []
    else:
        return [map(lambda l: l[0],
                    ptss)] + transpose_ptss(map(lambda l: l[1:], ptss))


@shape_constructor(shape)
def surface_grid(ptss, is_closed_u=False, is_closed_v=False):
    ptss = [[loc_in_world(pt) for pt in pts] for pts in ptss]
    for pts in ptss:
        tikz_closed_line(pts)
    for pts in transpose_ptss(ptss):
        tikz_closed_line(map(loc_in_world, pts))



def view(camera=False, target=False, lens=False):
    if camera and target and lens:
        tikz_set_view(camera, target, lens)
        return camera, target, lens
    else:
        return ViewCamera(), ViewTarget(), ViewLens()



if( __name__ == '__main__' ):
    print("The Khepri library is not intended to be executed, just imported")
